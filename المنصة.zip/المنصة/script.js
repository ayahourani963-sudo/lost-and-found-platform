var pages=["home","signup","login","notifications","verify","about","contact","reports","lost","found","detail","edit","update","close","matches","search","problem","claims","chat"];
var N=[
 {id:1,t:"match",i:"🎯",h:"مطابقة جديدة محتملة",p:"تم العثور على «محفظة جلدية سوداء» تشبه بلاغك المفقود في دمشق – المزة.",w:"قبل ٥ دقائق",u:1,go:"verify"},
 {id:2,t:"msg",i:"✉️",h:"رسالة من أحمد",p:"مرحباً، أعتقد أن المفاتيح التي نشرتها هي لسيارتي، هل يمكننا التواصل؟",w:"قبل ساعة",u:1},
 {id:3,t:"comment",i:"💬",h:"تعليق جديد على بلاغك",p:"رأيت شيئاً مشابهاً قرب موقف الباصات في الفرقان.",w:"قبل ٣ ساعات",u:1},
 {id:4,t:"match",i:"🎯",h:"مطابقة جديدة محتملة",p:"هاتف سامسونج موجود في اللاذقية قد يكون هاتفك.",w:"أمس",u:0,go:"verify"},
 {id:5,t:"msg",i:"✉️",h:"رسالة من فريق لقيتها",p:"تم قبول بلاغك ونشره بنجاح. شكراً لمساهمتك.",w:"قبل يومين",u:0}
];
var filter="all";
function $(i){return document.getElementById(i)}
function toast(m){var t=$("toast");t.textContent=m;t.hidden=false;clearTimeout(toast.x);toast.x=setTimeout(function(){t.hidden=true},2600)}
function route(){
  var h=(location.hash||"#home").slice(1);if(pages.indexOf(h)<0)h="home";
  document.querySelectorAll("[data-p]").forEach(function(s){s.hidden=s.dataset.p!==h});
  if(h==="verify"){$("vform").hidden=false;$("vok").hidden=true}
  window.scrollTo(0,0);
}
function render(){
  var c=N.filter(function(n){return n.u}).length;$("cnt").textContent=c||"";$("cnt").hidden=!c;
  var l=N.filter(function(n){return filter==="all"||n.t===filter});
  $("list").innerHTML=l.length?l.map(function(n){
    return '<div class="nt '+(n.u?'unread':'')+'"><div class="ic">'+n.i+'</div><div class="b"><h4>'+n.h+'</h4><div>'+n.p+'</div><div class="muted">'+n.w+'</div>'+
    (n.go?'<a class="btn" style="margin-top:8px;padding:6px 16px" href="#verify" data-r="'+n.id+'">أنا صاحب الغرض – تحقّق</a>':'')+'</div></div>'}).join(""):'<div class="card muted">لا توجد إشعارات.</div>';
}
$("tabs").onclick=function(e){var b=e.target.closest("button");if(!b)return;
  if(b.id==="readall"){N.forEach(function(n){n.u=0});render();return}
  filter=b.dataset.f;this.querySelectorAll("button").forEach(function(x){x.classList.toggle("on",x===b)});render()};
$("list").onclick=function(e){var a=e.target.closest("[data-r]");if(a){N.forEach(function(n){if(n.id==a.dataset.r)n.u=0});render()}};
$("fs").onsubmit=function(e){e.preventDefault();
  var f=["s1","s2","s3","s5","s6"].some(function(i){return !$(i).value.trim()});
  if(f)return $("e1").textContent="يرجى تعبئة جميع الحقول المطلوبة.";
  if($("s6").value.length<6)return $("e1").textContent="كلمة المرور يجب ألا تقل عن ٦ أحرف.";
  if($("s6").value!==$("s7").value)return $("e1").textContent="كلمتا المرور غير متطابقتين.";
  $("e1").textContent="";toast("تم إنشاء حسابك بنجاح 🎉");location.hash="notifications"};
$("fl").onsubmit=function(e){e.preventDefault();
  if(!$("l1").value.trim()||!$("l2").value)return $("e2").textContent="أدخل بيانات الدخول كاملة.";
  $("e2").textContent="";toast("أهلاً بعودتك");location.hash="notifications"};
$("fv").onsubmit=function(e){e.preventDefault();
  if(!$("a1").value.trim()||!$("a2").value.trim()||!$("a3").value)return $("e3").textContent="يرجى الإجابة عن الأسئلة ١ و٢ و٣ على الأقل.";
  $("e3").textContent="";$("vform").hidden=true;$("vok").hidden=false;window.scrollTo(0,0)};
window.addEventListener("hashchange",route);
var seq=0,cur=1,rk="all",today=new Date().toISOString().slice(0,10);
var ICON={"محفظة":"👛","مفاتيح":"🔑","هاتف":"📱","حقيبة":"🎒","وثائق":"🪪","حيوان أليف":"🐾","أخرى":"📦"},CATS=Object.keys(ICON),
COLS=["أسود","أبيض","أزرق","أحمر","أخضر","بني","رمادي","أخرى"],
GOV=["دمشق","ريف دمشق","حلب","حمص","حماة","اللاذقية","طرطوس","إدلب","درعا","السويداء","القنيطرة","دير الزور","الرقة","الحسكة"],
NB={0:[1,10],1:[0,8],2:[7,12],3:[4,6],4:[3,7],5:[6,7],6:[5,3],7:[2,4,5],8:[9,1],9:[8],10:[0,8],11:[12,13],12:[2,11],13:[11,12]},
ST={open:"مفتوح",solved:"تم الحل",closed:"مغلق"},
CH=[{me:0,x:"مرحباً، أعتقد أن هذا الغرض لي."},{me:1,x:"أهلاً، تم قبول طلبك. متى يناسبك الاستلام؟"}],D={};
function mkcl(){return[{n:"سامر حداد",a:["بطانة حمراء","هوية وبطاقة بنكية"],s:"new"},{n:"لينا منصور",a:["لا أذكر بالضبط","بطاقة فقط"],s:"new"}]}
function mk(k,t,c,col,g,pl,d,ds,own,q){return{id:++seq,k:k,t:t,c:c,col:col,g:g,pl:pl,d:d,ds:ds,own:own,q:q||["ما العلامة المميزة للغرض؟","ما الذي كان بداخله؟"],st:"open",u:[],img:null,cl:own?mkcl():[]}}
var R=[
mk("lost","محفظة جلدية سوداء","محفظة","أسود","دمشق","المزة","2026-10-29","ضاعت قرب موقف الباصات، فيها بطاقات وأوراق شخصية.",1),
mk("found","محفظة جلدية سوداء","محفظة","أسود","دمشق","المزة","2026-10-30","وُجدت قرب موقف الباصات بحالة جيدة.",0),
mk("found","مفاتيح سيارة","مفاتيح","رمادي","حلب","الفرقان","2026-10-31","حلقة مفاتيح مع ميدالية صغيرة.",1,["ما ماركة السيارة؟","كم عدد المفاتيح في الحلقة؟"]),
mk("lost","هاتف سامسونج","هاتف","أسود","اللاذقية","الكورنيش","2026-10-28","هاتف بغلاف شفاف.",0),
mk("found","حقيبة مدرسية","حقيبة","أزرق","حمص","الحمرا","2026-10-30","حقيبة فيها دفاتر وأقلام.",0),
mk("lost","قطة شيرازي بيضاء","حيوان أليف","أبيض","دمشق","باب توما","2026-10-31","ترتدي طوقاً أحمر.",0)];
function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function opt(a,s,all){return(all?'<option value="">'+all+'</option>':'')+a.map(function(x){return'<option'+(x===s?' selected':'')+'>'+x+'</option>'}).join("")}
function fnd(i){return R.filter(function(r){return r.id==i})[0]}
function thumb(r,h){return'<div class="th" style="height:'+(h||110)+'px">'+(r.img?'<img src="'+r.img+'" alt="">':ICON[r.c])+'</div>'}
function tag(r){return'<span class="tag '+r.k+'">'+(r.k=="lost"?"مفقود":"موجود")+'</span> <span class="tag st '+r.st+'">'+ST[r.st]+'</span>'}
function card(r,x){return'<a class="card" href="#detail" data-id="'+r.id+'">'+thumb(r)+tag(r)+'<h3 style="margin:8px 0 2px">'+esc(r.t)+'</h3><div class="muted">📍 '+esc(r.g)+' – '+esc(r.pl)+' · '+r.d+'</div>'+(x||"")+'</a>'}
function ups(r){return r.u.length?'<h3>المستجدات</h3>'+r.u.map(function(u){return'<div class="note">🕒 '+u.w+' — '+esc(u.x)+'</div>'}).join(""):''}
function er(f,m){f.querySelector(".err").textContent=m}
function form(k,r){var f=r||{},fo=r?r.k=="found":k=="found";
return'<h1>'+(r?'✏️ تعديل البلاغ':fo?'🤲 تسجيل غرض معثور عليه':'📢 تسجيل غرض مفقود')+'</h1><form id="ff" data-k="'+(r?'edit':k)+'" novalidate>'+
'<label>اسم الغرض</label><input name="t" value="'+esc(f.t)+'" placeholder="مثال: محفظة جلدية سوداء">'+
'<div class="row"><div><label>الفئة</label><select name="c">'+opt(CATS,f.c)+'</select></div><div><label>اللون</label><select name="col">'+opt(COLS,f.col)+'</select></div></div>'+
'<div class="row"><div><label>المحافظة</label><select name="g">'+opt(GOV,f.g)+'</select></div><div><label>المنطقة / الحي</label><input name="pl" value="'+esc(f.pl)+'"></div></div>'+
'<div class="row"><div><label>'+(fo?'تاريخ العثور':'تاريخ الفقد')+'</label><input type="date" name="d" value="'+(f.d||today)+'"></div><div><label>صورة الغرض</label><input type="file" name="img" accept="image/*"></div></div>'+
'<label>وصف تفصيلي</label><textarea name="ds" rows="3">'+esc(f.ds)+'</textarea>'+
(fo?'<div class="note">🔐 ضع سؤالين يجيب عنهما صاحب الغرض الحقيقي، ولا تذكر إجابتهما في الوصف.</div><label>سؤال التحقق ١</label><input name="q1" value="'+esc(f.q&&f.q[0])+'"><label>سؤال التحقق ٢</label><input name="q2" value="'+esc(f.q&&f.q[1])+'">':'')+
'<div class="err"></div><button class="btn full">'+(r?'حفظ التعديلات':'نشر البلاغ')+'</button><a class="btn line full" style="text-align:center" href="#'+(r?'detail':'reports')+'">إلغاء</a></form>'}
function score(a,b){var s=0;if(a.c==b.c)s+=40;if(a.col==b.col)s+=20;if(a.g==b.g)s+=25;else if((NB[GOV.indexOf(a.g)]||[]).indexOf(GOV.indexOf(b.g))>-1)s+=10;if(a.t.split(" ").some(function(x){return x.length>2&&b.t.indexOf(x)>-1}))s+=15;return s}
D.lost=function(){$("p_lost").innerHTML=form("lost")};
D.found=function(){$("p_found").innerHTML=form("found")};
D.edit=function(){$("p_edit").innerHTML=form("edit",fnd(cur))};
D.reports=function(){var l=R.filter(function(r){return rk=="all"||r.k==rk});
$("p_reports").innerHTML='<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><h1 style="margin:0;flex:1">📋 البلاغات</h1><a class="btn" href="#lost">＋ مفقود</a><a class="btn navy" href="#found">＋ موجود</a></div><div class="tabs" id="rt" style="margin-top:14px">'+[["all","الكل"],["lost","مفقودات"],["found","موجودات"]].map(function(x){return'<button data-k="'+x[0]+'"'+(rk==x[0]?' class="on"':'')+'>'+x[1]+'</button>'}).join("")+'<a class="btn line" href="#search" style="margin-inline-start:auto;padding:4px 16px">🔎 بحث متقدم</a></div><div class="grid">'+(l.map(function(r){return card(r)}).join("")||'<p class="muted">لا توجد بلاغات.</p>')+'</div>'};
D.detail=function(){var r=fnd(cur),info=[["الفئة",r.c],["اللون",r.col],["المحافظة",r.g],["المنطقة",r.pl],["التاريخ",r.d],["رقم البلاغ","#"+(4800+r.id)]];
var A=r.own?'<a class="btn line" href="#edit">✏️ تعديل</a><a class="btn line" href="#update">📝 تحديث</a><a class="btn line" href="#matches">🎯 المطابقات</a><a class="btn line" href="#claims">🙋 طلبات المطالبة</a><a class="btn navy" href="#close">إغلاق البلاغ</a>':'<a class="btn" href="#verify">✋ هذا غرضي – تحقّق</a><a class="btn line" href="#chat">💬 مراسلة</a>';
$("p_detail").innerHTML='<a href="#reports" class="muted">→ رجوع للبلاغات</a>'+thumb(r,230)+'<div style="margin:12px 0">'+tag(r)+'</div><h1>'+esc(r.t)+'</h1><div class="grid" style="margin:12px 0;grid-template-columns:repeat(auto-fit,minmax(140px,1fr))">'+info.map(function(x){return'<div class="q" style="margin:0"><span class="muted">'+x[0]+'</span><br><b>'+esc(x[1])+'</b></div>'}).join("")+'</div><h3>الوصف</h3><p>'+(esc(r.ds)||"—")+'</p>'+ups(r)+'<div class="cta" style="justify-content:flex-start;margin-top:16px">'+A+'</div>'};
D.update=function(){var r=fnd(cur);$("p_update").innerHTML='<h1>📝 تحديث البلاغ</h1><div class="muted">'+esc(r.t)+'</div><form id="fu" novalidate><label>تفاصيل جديدة طرأت على البلاغ</label><textarea name="x" rows="4" placeholder="مثال: تذكرت أنني فقدتها قرب سوق الحميدية"></textarea><div class="err"></div><button class="btn full">نشر التحديث</button></form>'+ups(r)};
D.close=function(){var r=fnd(cur);$("p_close").innerHTML='<h1>🔒 إغلاق البلاغ</h1><div class="muted">'+esc(r.t)+'</div><form id="fx"><label><input type="radio" name="s" value="solved" checked style="width:auto"> ✅ تم الحل – استرجعت الغرض أو سُلِّم لصاحبه</label><label><input type="radio" name="s" value="closed" style="width:auto"> 🔒 مغلق – لا أرغب بمتابعة البلاغ</label><label>ملاحظة (اختياري)</label><textarea name="x" rows="2"></textarea><div class="note">بعد الإغلاق لن يظهر البلاغ في نتائج المطابقة.</div><button class="btn full">تأكيد</button><a class="btn line full" style="text-align:center" href="#detail">إلغاء</a></form>'};
D.matches=function(){var r=fnd(cur),m=R.filter(function(x){return x.k!=r.k&&x.st=="open"}).map(function(x){return[x,score(r,x)]}).filter(function(p){return p[1]>=40}).sort(function(a,b){return b[1]-a[1]});
$("p_matches").innerHTML='<h1>🎯 المطابقات المحتملة</h1><div class="muted">أغراض قريبة من مواصفات: <b>'+esc(r.t)+'</b></div><div class="grid" style="margin-top:14px">'+(m.map(function(p){return card(p[0],'<div class="bar2"><i style="width:'+p[1]+'%"></i></div><b style="color:var(--orange)">نسبة التطابق '+p[1]+'٪</b>')}).join("")||'<p class="muted">لا توجد مطابقات حالياً، وسنُشعرك فور ظهور غرض مشابه.</p>')+'</div><div class="cta" style="margin-top:16px"><a class="btn line" href="#search">🔎 توسيع البحث</a><a class="btn" href="#detail">رجوع للبلاغ</a></div>'};
D.search=function(){var b=$("p_search");if(!b.innerHTML)b.innerHTML='<h1>🔎 البحث المتقدم</h1><form id="fsr" novalidate><label>كلمة مفتاحية</label><input name="q" placeholder="محفظة، مفاتيح…"><div class="row"><div><label>النوع</label><select name="k"><option value="">الكل</option><option value="lost">مفقود</option><option value="found">موجود</option></select></div><div><label>الفئة</label><select name="c">'+opt(CATS,"","الكل")+'</select></div></div><div class="row"><div><label>اللون</label><select name="col">'+opt(COLS,"","الكل")+'</select></div><div><label>المحافظة</label><select name="g">'+opt(GOV,"","الكل")+'</select></div></div><label>من تاريخ</label><input type="date" name="d"><label style="font-weight:400"><input type="checkbox" name="ex" style="width:auto"> توسيع النطاق (يشمل المحافظات المجاورة)</label><label style="font-weight:400"><input type="checkbox" name="rl" style="width:auto"> تخفيف المعايير (يكفي تطابق معيار واحد)</label></form><h3 id="scn"></h3><div class="grid" id="srl"></div>';sr()};
function sr(){var f=$("fsr").elements,q=f.q.value.trim(),k=f.k.value,c=f.c.value,col=f.col.value,g=f.g.value,d=f.d.value,gs=g?[g]:[];if(g&&f.ex.checked)(NB[GOV.indexOf(g)]||[]).forEach(function(i){gs.push(GOV[i])});
var l=R.filter(function(r){var cr=[];if(c)cr.push(r.c==c);if(col)cr.push(r.col==col);if(g)cr.push(gs.indexOf(r.g)>-1);if(d)cr.push(r.d>=d);var ok=!cr.length||(f.rl.checked?cr.some(Boolean):cr.every(Boolean));return ok&&(!k||r.k==k)&&(!q||(r.t+" "+r.ds).indexOf(q)>-1)});
$("scn").textContent="النتائج: "+l.length;$("srl").innerHTML=l.map(function(r){return card(r)}).join("")||'<p class="muted">لا نتائج. جرّب توسيع النطاق أو تخفيف المعايير.</p>'}
D.problem=function(){$("p_problem").innerHTML='<h1>🛠️ الإبلاغ عن مشكلة</h1><div class="muted">أخبرنا بالمشكلة التقنية وسيتابعها فريق الدعم.</div><form id="fp" novalidate><label>نوع المشكلة</label><select name="t"><option>خطأ في التطبيق</option><option>مشكلة في رفع الصور</option><option>الإشعارات لا تصل</option><option>مشكلة في تسجيل الدخول</option><option>أخرى</option></select><label>الصفحة المتأثرة</label><input name="p" placeholder="مثال: صفحة البلاغات"><label>وصف المشكلة</label><textarea name="x" rows="4"></textarea><div class="err"></div><button class="btn full">إرسال</button></form>'};
D.claims=function(){var r=fnd(cur);$("p_claims").innerHTML='<h1>🙋 طلبات المطالبة بالملكية</h1><div class="muted">'+esc(r.t)+'</div>'+(r.cl.map(function(c,i){return'<div class="card" style="margin-top:12px"><div class="cinfo" style="margin:0"><div class="ic">👤</div><b style="flex:1">'+c.n+'</b><span class="tag st '+(c.s=="ok"?"solved":"")+'">'+({new:"قيد المراجعة",ok:"مقبول",no:"مرفوض"})[c.s]+'</span></div><details style="margin:10px 0"><summary style="cursor:pointer;color:var(--orange);font-weight:600">عرض الإجابات</summary>'+r.q.map(function(q,j){return'<div class="q"><b>'+esc(q)+'</b><div>'+esc(c.a[j]||"—")+'</div></div>'}).join("")+'</details>'+(c.s=="new"?'<button class="btn" data-cl="'+i+'" data-v="ok">✅ قبول</button> <button class="btn line" data-cl="'+i+'" data-v="no">❌ رفض</button>':c.s=="ok"?'<a class="btn" href="#chat">💬 فتح المحادثة</a>':'')+'</div>'}).join("")||'<p class="muted">لا توجد طلبات بعد.</p>')};
D.chat=function(){var r=fnd(cur)||{t:""};$("p_chat").innerHTML='<h1>💬 مركز التواصل</h1><div class="muted">محادثة حول: <b>'+esc(r.t)+'</b> · مع سامر حداد</div><div class="chat" id="cb">'+CH.map(function(m){return'<div class="m'+(m.me?" me":"")+'">'+esc(m.x)+'</div>'}).join("")+'</div><form id="fm" style="display:flex;gap:8px;margin-top:10px"><input name="x" placeholder="اكتب رسالتك…" autocomplete="off"><button class="btn">إرسال</button></form>';$("cb").scrollTop=1e5};
function draw(){var f=D[(location.hash||"#home").slice(1)];if(f)f()}
["reports","lost","found","detail","edit","update","close","matches","search","problem","claims","chat"].forEach(function(n){var s=document.createElement("section");s.dataset.p=n;s.hidden=true;s.innerHTML='<div class="box wide'+(n=="reports"?" full":"")+'" id="p_'+n+'"></div>';document.querySelector("main").appendChild(s)});
document.addEventListener("click",function(e){var a=e.target.closest("[data-id]");if(a)cur=+a.dataset.id;var b=e.target.closest("#rt button");if(b){rk=b.dataset.k;D.reports()}var c=e.target.closest("[data-cl]");if(c){fnd(cur).cl[+c.dataset.cl].s=c.dataset.v;toast(c.dataset.v=="ok"?"تم القبول، يمكنك مراسلته الآن":"تم رفض الطلب");D.claims()}});
document.addEventListener("input",function(e){if(e.target.form&&e.target.form.id=="fsr")sr()});
document.addEventListener("submit",function(e){var f=e.target,id=f.id;if(["ff","fu","fx","fp","fm"].indexOf(id)<0)return;e.preventDefault();
var v=function(n){return f.elements[n]?f.elements[n].value.trim():""},r=fnd(cur);
if(id=="ff"){if(!v("t")||!v("pl"))return er(f,"أدخل اسم الغرض والمنطقة.");
var fin=function(img){var ed=f.dataset.k=="edit",x=ed?r:mk(f.dataset.k,"","","","","","","",1);x.t=v("t");x.c=v("c");x.col=v("col");x.g=v("g");x.pl=v("pl");x.d=v("d");x.ds=v("ds");if(f.elements.q1)x.q=[v("q1")||x.q[0],v("q2")||x.q[1]];if(img)x.img=img;if(!ed)R.unshift(x);cur=x.id;toast(ed?"تم حفظ التعديلات ✅":"تم تسجيل البلاغ ✅");location.hash=ed?"detail":"matches"};
var fl=f.elements.img.files[0];if(fl){var fr=new FileReader();fr.onload=function(){fin(fr.result)};fr.readAsDataURL(fl)}else fin()}
if(id=="fu"){if(!v("x"))return er(f,"اكتب التفاصيل الجديدة.");r.u.unshift({w:today,x:v("x")});toast("تم نشر التحديث ✅");location.hash="detail"}
if(id=="fx"){r.st=v("s")||"solved";if(v("x"))r.u.unshift({w:today,x:"ملاحظة الإغلاق: "+v("x")});toast(r.st=="solved"?"تم تحديث الحالة: تم الحل 🎉":"تم إغلاق البلاغ");location.hash="detail"}
if(id=="fp"){if(!v("x"))return er(f,"صف المشكلة باختصار.");f.reset();toast("وصل بلاغك، رقم التذكرة #"+(1000+Math.floor(Math.random()*9000)))}
if(id=="fm"){if(!v("x"))return;CH.push({me:1,x:v("x")});D.chat();setTimeout(function(){CH.push({me:0,x:"شكراً لك، سأتواصل معك قريباً."});if(location.hash=="#chat")D.chat()},1200)}});
window.addEventListener("hashchange",draw);

$("fc").onsubmit=function(e){e.preventDefault();
  if(!$("c1").value.trim()||!$("c2").value.trim()||!$("c4").value.trim())return $("e4").textContent="يرجى تعبئة الاسم والبريد والرسالة.";
  $("e4").textContent="";this.reset();toast("وصلتنا رسالتك، شكراً لك 🧡")};
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12});
function anim(){
  document.querySelectorAll('section[data-p="home"]:not([hidden]) :is(.card,h2,.stats div),section[data-p="about"]:not([hidden]) :is(.card,h2),section[data-p="contact"]:not([hidden]) .card').forEach(function(el){if(!el.classList.contains("rv")){el.classList.add("rv");io.observe(el)}});
  document.querySelectorAll("section:not([hidden]) .cn").forEach(function(b){if(b.dataset.d)return;b.dataset.d=1;var n=+b.dataset.n,s=null;function st(t){s=s||t;var p=Math.min((t-s)/1500,1);b.textContent=Math.round(n*p).toLocaleString("ar-EG");if(p<1)requestAnimationFrame(st)}requestAnimationFrame(st)});
}
window.addEventListener("hashchange",anim);
render();draw();route();anim();
